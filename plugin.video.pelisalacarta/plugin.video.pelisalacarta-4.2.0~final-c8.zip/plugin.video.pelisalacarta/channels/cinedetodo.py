# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# pelisalacarta - XBMC Plugin
# Canal para cinedetodo
# http://blog.tvalacarta.info/plugin-xbmc/pelisalacarta/
# ------------------------------------------------------------

import re

from core import config
from core import httptools
from core import logger
from core import scrapertools
from core.item import Item

__modo_grafico__ = config.get_setting("modo_grafico", "cinedetodo")
__perfil__ = config.get_setting("perfil", "cinedetodo")

# Fijar perfil de color            
perfil = [['0xFFFFE6CC', '0xFFFFCE9C', '0xFF994D00', '0xFFFE2E2E', '0xFFFFD700'],
          ['0xFFA5F6AF', '0xFF5FDA6D', '0xFF11811E', '0xFFFE2E2E', '0xFFFFD700'],
          ['0xFF58D3F7', '0xFF2E9AFE', '0xFF2E64FE', '0xFFFE2E2E', '0xFFFFD700']]
if __perfil__ < 3:
    color1, color2, color3, color4, color5 = perfil[__perfil__]
else:
    color1 = color2 = color3 = color4 = color5 = ""

host = "http://www.cinedetodo.com"


def mainlist(item):
    logger.info()
    itemlist = []
    item.text_color = color1

    itemlist.append(item.clone(title="Películas", action="", text_color=color2))
    item.contentType = "movie"
    itemlist.append(item.clone(title="     Novedades", action="listado", url=host))
    itemlist.append(item.clone(title="     Castellano", action="listado", url="%s/castellano/" % host))
    itemlist.append(item.clone(title="     Latino", action="listado", url="%s/latino/" % host))
    itemlist.append(item.clone(title="     Subtituladas", action="listado", url="%s/subtitulada/" % host))
    itemlist.append(item.clone(title="     Géneros", action="genero"))

    itemlist.append(item.clone(action="search", title="Buscar...", text_color=color2))

    itemlist.append(item.clone(title="Configuración del canal", action="configuracion", text_color="gold"))

    return itemlist


def configuracion(item):
    from platformcode import platformtools
    ret = platformtools.show_channel_settings()
    platformtools.itemlist_refresh()
    return ret


def search(item, texto):
    logger.info()
    try:
        item.url = "%s/?s=%s"  % (host, texto.replace(" ", "+"))
        item.action = "listado"
        return listado(item)
    # Se captura la excepción, para no interrumpir al buscador global si un canal falla
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []


def listado(item):
    logger.info()
    itemlist = []
    item.text_color = color2

    data = httptools.downloadpage(item.url).data
    patron = '<li class="TPostMv">.*?href="([^"]+)".*?src="([^"]+)".*?<h2 class="Title">(.*?)\s*(?: \||)</h2>' \
             '.*?<span class="Year">(\d+)'
    matches = scrapertools.find_multiple_matches(data, patron)
    for url, thumb, title, year in matches:
        if "|" in title:
            titulo = title.split(" | ")
            titulo = re.sub(r' \(\d+\)', '', titulo[1])
        else:
            titulo = re.sub(r' \(\d+\)', '', title)
        new_item = item.clone(action="findvideos", url=url, thumbnail=thumb, contentTitle=titulo, title=title,
                              context="buscar_trailer")

        if year:
            new_item.infoLabels['year'] = year
            year = " (%s)" % year
            if not year in title:
                new_item.title += year
        itemlist.append(new_item)

    try:
        from core import tmdb
        tmdb.set_infoLabels_itemlist(itemlist, __modo_grafico__)
    except:
        pass

    next_page = scrapertools.find_single_match(data, '<a class="nextpostslink" rel="next" href="([^"]+)"')
    if next_page:
        itemlist.append(item.clone(url=next_page, title=">> Página Siguiente", text_color=color3))
        
    return itemlist


def genero(item):
    logger.info()
    itemlist = []

    data = httptools.downloadpage(host).data

    exclude = ['Castellano', 'Latino', 'Subtitulada']
    bloque = scrapertools.find_single_match(data, '<ul class="sub-menu">(.*?)</ul>')
    patron = '<a href="([^"]+)">(.*?)</a>'
    matches = scrapertools.find_multiple_matches(data, patron)
    for url, title in matches:
        if title in exclude: continue
        itemlist.append(item.clone(title=title, action="listado", url=url, text_color=color2))

    return itemlist


def findvideos(item):
    logger.info()

    itemlist = []
    item.text_color = color3

    data = httptools.downloadpage(item.url).data
    matches = scrapertools.find_multiple_matches(data, 'data-TPlayerNv="([^"]+)">(.*?)</li>')
    for opt, title in matches:
        if "Tráiler" in title: continue
        title = scrapertools.htmlclean(title)
        title = re.sub(r'Opción \d+ ', '', title)
        url = scrapertools.find_single_match(data, 'id="%s"><iframe.*?src="([^"]+)"' % opt)
        if not url.startswith("http:"):
            url = "http:%s" % url
        server = scrapertools.find_single_match(url, '//(?:www.|)(.*?)\.')
        if server == "youtube": server = "Directo"
        title = "%s - %s" % (server.capitalize(), title)
        itemlist.append(item.clone(action="play", title=title, url=url))

    bloque = scrapertools.find_single_match(data, '<h2 class="dlmt">Opciones de descarga</h2>(.*?)</tbody>')
    patron = '<td><a class="Button STPb" href="([^"]+)".*?<img.*?>([^<]+)</td>.*?<td>(.*?)</td>' \
             '.*?<td>\s*(.*?)</td>'
    matches = scrapertools.find_multiple_matches(bloque, patron)
    for url, server, idioma, calidad in matches:
        calidad = calidad.replace("\xc2\xa0", "")
        title = "%s - %s - %s" % (server.capitalize(), idioma, calidad.strip())
        itemlist.append(item.clone(url=url, action="play", title=title))

    if not itemlist:
        itemlist.append(item.clone(action="", title="No hay enlaces disponibles"))
    elif item.contentType == "movie" and config.get_library_support():
        itemlist.append(Item(channel=item.channel, title="Añadir esta película a la biblioteca", url=item.url,
                             action="add_pelicula_to_library", text_color="green", thumbnail=item.thumbnail,
                             infoLabels=item.infoLabels, fanart=item.fanart))

    return itemlist


def play(item):
    logger.info()
    itemlist = []

    if "googleapis" in item.url or "docid=" in item.url:
        import urllib
        docid = scrapertools.find_single_match(item.url, 'docid=([^&]+)&')
        url = "http://docs.google.com/get_video_info?docid=%s" % docid

        headers = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20150101 Firefox/47.0 (Chrome)',
            'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'en-us,en;q=0.5',
        }
        response = httptools.downloadpage(url, cookies=False)
        cookies = ""
        cookie = response.headers["set-cookie"].split("HttpOnly, ")
        for c in cookie:
            cookies += c.split(";", 1)[0]+"; "

        data = response.data.decode('unicode-escape')
        data = urllib.unquote_plus(urllib.unquote_plus(data))

        headers_string = "|"
        for key, value in headers.items():
            headers_string += key + "=" + value + "&"
        headers_string += "Cookie="+cookies
        url_streams = scrapertools.find_single_match(data, 'url_encoded_fmt_stream_map=(.*)')
        streams = scrapertools.find_multiple_matches(url_streams, 'url=(.*?)(?:;.*?quality=(.*?)(?:,|&)|&quality=(.*?)(?:,|&))')
        for video_url, quality, quality2 in streams:
            ext = scrapertools.find_single_match(video_url, '&type=video/(?:x-|)(.*)').encode('utf-8')
            if ext == "mp4":
                ext = ".mp4"
            video_url += headers_string
            quality = quality.encode('utf-8')
            if not quality:
                quality = quality2.encode('utf-8')
            itemlist.append(['%s %s [directo]' % (ext, quality), video_url])
        itemlist.sort(key=lambda it:it[0], reverse=True)
    else:
        from core import servertools
        enlaces = servertools.findvideos(item.url, True)
        if enlaces:
            itemlist.append(item.clone(url=enlaces[0][1], server=enlaces[0][2]))

    return itemlist
