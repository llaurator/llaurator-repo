# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# pelisalacarta - XBMC Plugin
# Canal para playview
# http://blog.tvalacarta.info/plugin-xbmc/pelisalacarta/
# ------------------------------------------------------------

import re

from core import config
from core import httptools
from core import logger
from core import scrapertools
from core.item import Item

__modo_grafico__ = config.get_setting("modo_grafico", "playview")
__perfil__ = config.get_setting("perfil", "playview")

# Fijar perfil de color            
perfil = [['0xFFFFE6CC', '0xFFFFCE9C', '0xFF994D00', '0xFFFE2E2E', '0xFFFFD700'],
          ['0xFFA5F6AF', '0xFF5FDA6D', '0xFF11811E', '0xFFFE2E2E', '0xFFFFD700'],
          ['0xFF58D3F7', '0xFF2E9AFE', '0xFF2E64FE', '0xFFFE2E2E', '0xFFFFD700']]
if __perfil__ < 3:
    color1, color2, color3, color4, color5 = perfil[__perfil__]
else:
    color1 = color2 = color3 = color4 = color5 = ""

host = "http://playview.io"


def mainlist(item):
    logger.info()
    itemlist = []
    item.text_color = color1

    itemlist.append(item.clone(title="Películas", action="", text_color=color2))
    item.contentType = "movie"
    itemlist.append(item.clone(title="     Novedades", action="listado", url="%s/peliculas-online" % host, page=0))
    itemlist.append(item.clone(title="     Géneros", action="genero"))

    item.contentType = "tvshow"
    itemlist.append(item.clone(title="Series", action="listado_serie", url="%s/series-online" % host, text_color=color2, page=0))
    itemlist.append(item.clone(title="Series Animadas", action="listado_serie", url="%s/series-animadas-online" % host, text_color=color2, page=0))
    itemlist.append(item.clone(title="Dramas", action="listado_serie", url="%s/dramas-online" % host, text_color=color2, page=0))
    itemlist.append(item.clone(title="Animes", action="listado_serie", url="%s/anime-online" % host, text_color=color2, page=0))
    itemlist.append(item.clone(title="Documentales", action="listado_serie", url="%s/documentales" % host, text_color=color2, page=0, extra="busqueda"))

    itemlist.append(item.clone(action="search", title="Buscar...", text_color=color2))

    itemlist.append(item.clone(title="Configuración del canal", action="configuracion", text_color="gold"))

    return itemlist


def configuracion(item):
    from platformcode import platformtools
    ret = platformtools.show_channel_settings()
    platformtools.itemlist_refresh()
    return ret


def search(item, texto):
    logger.info()
    try:
        item.url = "%s/search/%s"  % (host, texto.replace(" ", "+"))
        item.page = 0
        item.extra = "busqueda"
        item.action = "listado_serie"
        return listado_serie(item)
    # Se captura la excepción, para no interrumpir al buscador global si un canal falla
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []


def listado(item):
    logger.info()
    itemlist = []
    item.text_color = color2

    data = httptools.downloadpage(item.url).data
    patron = '<div class="spotlight_container">.*?data-original="([^"]+)".*?<div class="spotlight_title">\s*(.*?)\s*<' \
             '.*?<span class="slqual sres">(\d+).*?href="([^"]+)"'
    matches = scrapertools.find_multiple_matches(data, patron)
    for thumb, title, year, url in matches[item.page:item.page + 30]:
        new_item = item.clone(action="findvideos", url=url, thumbnail=thumb, contentTitle=title, title=title,
                              context="buscar_trailer")

        if year:
            new_item.title += "  (%s)" % year
            new_item.infoLabels['year'] = year
        itemlist.append(new_item)

    try:
        from core import tmdb
        tmdb.set_infoLabels_itemlist(itemlist, __modo_grafico__)
    except:
        pass

    if item.page + 30 < len(matches):
        itemlist.append(item.clone(page=item.page + 30, title=">> Página Siguiente", text_color=color3))
    else:
        next_page = scrapertools.find_single_match(data, '<a href="([^"]+)" class="page-link" aria-label="Next"')
        if next_page:
            itemlist.append(item.clone(url=next_page, page=0, title=">> Página Siguiente", text_color=color3))
        
    return itemlist


def listado_serie(item):
    logger.info()
    itemlist = []
    item.text_color = color2

    data = httptools.downloadpage(item.url).data
    patron = '<div class="spotlight_container">.*?data-original="([^"]+)".*?<div class="spotlight_title">\s*(.*?)\s*<' \
             '(.*?)<span class="slqual sres">(\d+).*?href="([^"]+)"'
    matches = scrapertools.find_multiple_matches(data, patron)
    for thumb, title, datos, year, url in matches[item.page:item.page + 30]:
        quality = scrapertools.find_single_match(datos, '<span class="slqual-HD">([^<]+)</span>')
        season = scrapertools.find_single_match(datos, 'Temporada</span>\s*(\d+)')
        epi = scrapertools.find_single_match(datos, 'Episodio</span>\s*(\d+)')
        status = scrapertools.find_single_match(datos, '<span class="hidden-xs label[^>]+>([^<]+)</span>')
        titulo = title
        show = title
        tipo = "tvshow"
        if season and epi:
            titulo = "%s  (T%s-E%s)" % (title, season, epi)
        elif season and not epi:
            titulo = "%s  (T%s)" % (title, season)
        elif not season and epi:
            titulo = "%s  (E%s)" % (title, epi)
        else:
            tipo = "movie"
            show = ""
        if status:
            titulo += " [%s]" % status
        elif quality and year:
            titulo += " [%s/%s]" % (quality, year)
        elif year:
            titulo += " [%s]" % year
        new_item = item.clone(action="episodios", url=url, thumbnail=thumb, contentTitle=title, title=titulo,
                              contentSerieName=show, context="buscar_trailer", season=season, contentType=tipo)

        if year:
            new_item.infoLabels['year'] = year
        itemlist.append(new_item)

    try:
        from core import tmdb
        tmdb.set_infoLabels_itemlist(itemlist, __modo_grafico__)
    except:
        pass

    if item.page + 30 < len(matches):
        itemlist.append(item.clone(page=item.page + 30, title=">> Página Siguiente", text_color=color3))
    else:
        next_page = scrapertools.find_single_match(data, '<a href="([^"]+)" class="page-link" aria-label="Next"')
        if next_page:
            itemlist.append(item.clone(url=next_page, page=0, title=">> Página Siguiente", text_color=color3))
        
    return itemlist


def genero(item):
    logger.info()
    itemlist = []

    data = httptools.downloadpage(host).data

    exclude = ['Pr&oacute;ximos Estrenos', 'Series', 'Series Animadas', 'Dramas', 'Series Anime', 'Documentales']
    patron = '<li value="[^"]+"><a href="([^"]+)">(.*?)</a>'
    matches = scrapertools.find_multiple_matches(data, patron)
    for url, title in matches:
        if title in exclude: continue
        itemlist.append(item.clone(title=title, action="listado", url=url, page=0, text_color=color2))

    itemlist.sort(key=lambda it:it.title)
    return itemlist


def episodios(item):
    logger.info()
    itemlist = []

    data = httptools.downloadpage(item.url).data
    if item.extra == "busqueda" and 'data-type="Movie"' in data:
        return findvideos(item)

    id = scrapertools.find_single_match(data, 'data-id="([^"]+)"')
    if not item.infoLabels.get("plot"):
        item.infoLabels["plot"] = scrapertools.find_single_match(data, 'itemprop="description">(.*?)</div>')
    if not item.fanart:
        item.fanart = scrapertools.find_single_match(data, 'data-original="([^"]+)"')

    season = scrapertools.find_single_match(data, '(?i)Temp.\s*(\d+)')
    post = "set=LoadOptionsEpisode&action=EpisodeList&id=%s&type=1" % id
    data_epi = httptools.downloadpage("%s/playview" % host, post).data
    patron = 'data-id="([^"]+)" data-episode="([^"]+)" value="[^"]*" title="([^"]+)"'
    epis = scrapertools.find_multiple_matches(data_epi, patron)
    for e_id, episode, title in epis:
        if re.search(r'\d+ - ', title):
            title = title.split("- ", 1)[1]
        titulo = "%sx%s - %s" % (season, episode, title)
        new_item = item.clone(action="findvideos", contentType="episode", id=e_id, url="", title=titulo, extra="")
        new_item.infoLabels['season'] = season
        new_item.infoLabels['episode'] = episode
        itemlist.append(new_item)

    itemlist.sort(key=lambda it: it.infoLabels.get('episode', 0), reverse=True)

    try:
        from core import tmdb
        tmdb.set_infoLabels_itemlist(itemlist, __modo_grafico__)
    except:
        pass

    if config.get_library_support() and not item.extra:
        itemlist.append(Item(channel=item.channel, title="Añadir esta serie a la biblioteca", url=item.url,
                             action="add_serie_to_library", extra="episodios", contentSerieName=item.contentSerieName,
                             text_color="green", thumbnail=item.thumbnail, infoLabels=item.infoLabels,
                             fanart=item.fanart))

    return itemlist


def findvideos(item):
    logger.info()

    itemlist = []
    item.text_color = color3

    set = "LoadOptionsEpisode"
    type = "1"
    id = item.id
    if item.contentType == "movie":
        set = "LoadOptions"
        data = httptools.downloadpage(item.url).data

        id, type = scrapertools.find_single_match(data, 'data-id="([^"]+)" data-type="([^"]+)"')
        if not item.infoLabels.get("plot"):
            item.infoLabels["plot"] = scrapertools.find_single_match(data, 'itemprop="description">(.*?)</div>')
        if not item.fanart:
            item.fanart = scrapertools.find_single_match(data, 'data-original="([^"]+)"')

    post = "set=%s&action=Step1&id=%s&type=%s" % (set, id, type)
    if item.id:
        post += "&episode=%s" % item.infoLabels["episode"]
    data_opc = httptools.downloadpage("%s/playview" % host, post).data
    calidades = scrapertools.find_multiple_matches(data_opc, 'data-quality="([^"]+)"')
    for c in calidades:
        post = "set=%s&action=Step2&id=%s&type=%s&quality=%s" % (set, id, type, c.replace(" ", "+"))
        if item.id:
            post += "&episode=%s" % item.infoLabels["episode"]
        data_opc = httptools.downloadpage("%s/playview" % host, post).data
        patron = 'data-id="([^"]+)">\s*<h4>([^<]+)</h4>.*?title="([^"]+)"'
        matches = scrapertools.find_multiple_matches(data_opc, patron)
        for v_id, idioma, server in matches:
            if server == "PlayWatch": continue
            url = "set=%s&action=Step3&id=%s&type=%s" % (set, v_id, type)
            if item.id:
                url += "&episode=%s" % item.infoLabels["episode"]
            title = "%s - %s - %s" % (server, idioma, c)
            itemlist.append(item.clone(action="play", url=url, title=title))

    if not itemlist:
        itemlist.append(item.clone(action="", title="No hay enlaces disponibles"))
    elif item.contentType == "movie" and config.get_library_support():
        itemlist.append(Item(channel=item.channel, title="Añadir esta película a la biblioteca", url=item.url,
                             action="add_pelicula_to_library", text_color="green", thumbnail=item.thumbnail,
                             infoLabels=item.infoLabels, fanart=item.fanart))

    return itemlist


def play(item):
    logger.info()
    itemlist = []

    data = httptools.downloadpage("%s/playview" % host, item.url).data
    url = scrapertools.find_single_match(data, '(?i)<iframe.*?src="([^"]+)"')

    from core import servertools
    enlaces = servertools.findvideos(url, True)
    if enlaces:
        itemlist.append(item.clone(url=enlaces[0][1], server=enlaces[0][2]))

    return itemlist
