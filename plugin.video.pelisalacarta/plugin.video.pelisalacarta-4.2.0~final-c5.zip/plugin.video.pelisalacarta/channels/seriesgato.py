# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# pelisalacarta - XBMC Plugin
# Canal para seriesgato
# http://blog.tvalacarta.info/plugin-xbmc/pelisalacarta/
# ------------------------------------------------------------

import base64
import re

from core import config
from core import httptools
from core import logger
from core import scrapertools
from core.item import Item

__modo_grafico__ = config.get_setting("modo_grafico", "seriesgato")
__perfil__ = config.get_setting("perfil", "seriesgato")

# Fijar perfil de color            
perfil = [['0xFFFFE6CC', '0xFFFFCE9C', '0xFF994D00', '0xFFFE2E2E', '0xFFFFD700'],
          ['0xFFA5F6AF', '0xFF5FDA6D', '0xFF11811E', '0xFFFE2E2E', '0xFFFFD700'],
          ['0xFF58D3F7', '0xFF2E9AFE', '0xFF2E64FE', '0xFFFE2E2E', '0xFFFFD700']]
if __perfil__ < 3:
    color1, color2, color3, color4, color5 = perfil[__perfil__]
else:
    color1 = color2 = color3 = color4 = color5 = ""
host = "https://www.seriesgato.com/"


def mainlist(item):
    logger.info()
    itemlist = []
    item.text_color = color1
    item.contentType = "tvshow"

    config.set_setting("url_error", False, "seriesgato")

    itemlist.append(item.clone(title="Nuevos capítulos", action="nuevos", url=host))
    itemlist.append(item.clone(title="En Emisión", action="listado", url="%s/series-en-emision.html" % host))
    itemlist.append(item.clone(title="Populares", action="listado", url="%s/series-populares.html" % host))
    itemlist.append(item.clone(title="Nuevas Series", action="listado", url="%s/recien-agregadas.html" % host))
    itemlist.append(item.clone(title="Por Género", action="indices", url=host, text_color=color3))
    itemlist.append(item.clone(title="Todas las Series", action="indices", url=host, text_color=color3))

    itemlist.append(item.clone(title="", action=""))
    itemlist.append(item.clone(title="Buscar...", action="search", text_color=color3))
    itemlist.append(item.clone(action="configuracion", title="Configurar canal...", text_color="gold", folder=False))

    return itemlist


def configuracion(item):
    from platformcode import platformtools
    ret = platformtools.show_channel_settings()
    platformtools.itemlist_refresh()
    return ret


def search(item, texto):
    logger.info()
    try:
        item.url = "%s/?q=%s"  % (host, texto.replace(" ", "+"))
        item.contentType = "tvshow"
        return listado(item)
    # Se captura la excepción, para no interrumpir al buscador global si un canal falla
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []


def nuevos(item):
    logger.info()
    itemlist = []
    item.text_color = color2

    data = get_data(item.url)
    patron = '<div class="portada">.*?<a href="([^"]+)".*?data-original="([^"]+)".*?>([^<]+)</a>'
    matches = scrapertools.find_multiple_matches(data, patron)
    for url, thumb, episode in matches:
        title = url.rsplit("/", 1)[1]
        title = re.split(r'(?i)-\d+x\d+-', title)[0].replace("-", " ").capitalize()
        thumb = thumb.replace("-200x294", "")
        fanart = thumb.replace("-p.", "-cover.")
        new_item = item.clone(action="findvideos", url=url, thumbnail=thumb, contentSerieName=title,
                              contentTitle=title, fulltitle=title, fanart=fanart)
        try:
            season, episode = re.split(r'x|X', episode)
            new_item.title = "%s  [%sx%s]" % (title, season, episode)
        except:
            new_item.title = title

        tvdb_id = scrapertools.find_single_match(url, '-(\d+).html')
        new_item.infoLabels['tvdb_id'] = tvdb_id
        itemlist.append(new_item)

    try:
        from core import tmdb
        tmdb.set_infoLabels_itemlist(itemlist, __modo_grafico__)
        for it in itemlist:
            if it.infoLabels.get("tmdb_id"):
                it.contentSerieName = it.contentTitle
                it.title = it.title.replace(it.fulltitle, it.contentTitle)
                it.fulltitle = it.contentTitle
    except:
        import traceback
        logger.info(traceback.format_exc())
        pass

    return itemlist


def listado(item):
    logger.info()
    itemlist = []
    item.text_color = color2

    data = get_data(item.url)
    patron = '<article class="recomendacion slide lazy" data-original="([^"]+)".*?<a href="([^"]+)"' \
             '.*?data-original="([^"]+)".*?>([^<]+)</a></h2>.*?<span class="emision">.*?>\s*([^<]+)</span>' \
             '.*?<span class="temporadas">.*?>\s*(\d+).*?<p class="sinopsis">(.*?)</p>'
    matches = scrapertools.find_multiple_matches(data, patron)
    for fanart, url, thumb, title, estado, seasons, plot in matches:
        thumb = thumb.replace("-200x294", "")
        fanart = fanart.replace("-768x432", "")

        new_item = item.clone(action="episodios", url=url, thumbnail=thumb, contentSerieName=title,
                              contentTitle=title, fanart=fanart, title=title, seasons=seasons, status=estado,
                              context="buscar_trailer")

        tvdb_id = scrapertools.find_single_match(url, '-(\d+).html')
        new_item.infoLabels['tvdb_id'] = tvdb_id
        new_item.infoLabels['plot'] = plot
        itemlist.append(new_item)

    try:
        from core import tmdb
        tmdb.set_infoLabels_itemlist(itemlist, __modo_grafico__)
        for it in itemlist:
            if it.infoLabels.get("tmdb_id"):
                it.contentSerieName = it.contentTitle
                it.title = it.contentTitle
            it.title += "   [COLOR %s][Temporadas:%s][/COLOR]" % (color4, it.seasons)
            if "Emisión" not in item.title:
                it.title += "  [COLOR %s](%s)[/COLOR]" % (color5, it.status)
    except:
        import traceback
        logger.info(traceback.format_exc())
        pass

    return itemlist



def indices(item):
    logger.info()
    itemlist = []

    data = get_data(item.url)
    if "Género" in item.title:
        bloque = scrapertools.find_single_match(data, '<section class="wMenuGeneros"(.*?)</ul>')
    else:
        bloque = scrapertools.find_single_match(data, '<section class="wMenuSeries"(.*?)</ul>')
    matches = scrapertools.find_multiple_matches(bloque, '<a href="([^"]+)">(.*?)</a>')
    for url, title in matches:
        action = "listado"
        infolabels = item.infoLabels
        thumb = ""
        show = ""
        extra = ""
        fanart = ""
        if "Género" not in item.title:
            action = "episodios"
            show = title
            thumb = url.replace("www.", "portadas.").replace("/s/", "/").replace(".html", "-p.jpg")
            fanart = thumb.replace("-p.", "-cover.")
            tvdb_id = scrapertools.find_single_match(url, '-(\d+).html')
            infolabels = {'tvdb_id': tvdb_id}
            extra = "completa"
            
        itemlist.append(Item(channel=item.channel, action=action, title=title, url=url, thumbnail=thumb,
                             contentType="tvshow", contentTitle=show, contentSerieName=show, text_color=color2,
                             infoLabels=infolabels, extra="", fanart=fanart))
        
    return itemlist


def episodios(item):
    logger.info()
    itemlist = []

    data = get_data(item.url)
    patron = '<td class="capitulo">.*?href="([^"]+)".*?<span class="cap">(.*?)</span>.*?' \
             '<span class="titulo">([^<]+)\s*<span class="fecha".*?>(.*?)</span>'
    matches = scrapertools.find_multiple_matches(data, patron)
    for url, title, nombre, fecha in matches:
        new_item = item.clone(action="findvideos", contentType="episode")
        episode = scrapertools.get_season_and_episode(title)
        nombre = nombre.strip()
        if not nombre:
            nombre = fecha
            
        try:
            new_item.infoLabels['season'] = episode.split("x")[0]
            new_item.infoLabels['episode'] = episode.split("x")[1]
            new_item.title = "%s - %s" % (episode, nombre)
        except:
            new_item.title = "%s - %s" % (title, nombre)

        itemlist.append(new_item)

    itemlist.sort(key=lambda it: (it.infoLabels.get('season', 0), it.infoLabels.get('episode', 0)), reverse=True)

    try:
        from core import tmdb
        tmdb.set_infoLabels_itemlist(itemlist, __modo_grafico__)
    except:
        pass

    if config.get_library_support() and not item.extra:
        itemlist.append(Item(channel=item.channel, title="Añadir esta serie a la biblioteca", url=item.url,
                             action="add_serie_to_library", extra="episodios", contentSerieName=item.contentSerieName,
                             text_color="green", thumbnail=item.thumbnail, infoLabels=item.infoLabels,
                             fanart=item.fanart))

    return itemlist


def findvideos(item):
    logger.info()

    itemlist = []
    item.text_color = color3

    data = get_data(item.url)

    bloque = scrapertools.find_single_match(data, '<ul class="opciones">(.*?)</ul>')
    patron = '<a href="#([^"]+)".*?>([^<]+)</span><br/>.*?<span>(.*?)</span>'
    matches = scrapertools.find_multiple_matches(bloque, patron)
    for id, server, info in matches:
        if "Patrocina" in server:
            continue
        anony = scrapertools.find_single_match(data, '<div class="player" id="%s">.*?iframe src="([^"]+)"' % id)
        anony = anony.rsplit("/", 1)[1]
        url = base64.b64decode(base64.b64decode(anony))
        title = "%s  -  %s" % (server, info)
        itemlist.append(item.clone(action="play", url=url, title=title))

    if not itemlist:
        itemlist.append(item.clone(action="", title="No hay enlaces disponibles"))
    if item.extra == "nuevos":
        url = scrapertools.find_single_match(data, '(?i)href="([^"]+)">Todos los Cap')
        if url:
            itemlist.append(item.clone(action="episodios", url=url, title="Ir a lista de capítulos",
                                       text_color=color4))

    return itemlist


def play(item):
    logger.info()
    itemlist = []

    from core import servertools
    enlaces = servertools.findvideos(item.url, True)
    if enlaces:
        itemlist.append(item.clone(url=enlaces[0][1], server=enlaces[0][2]))

    return itemlist


def get_data(url_orig):
    try:
        if config.get_setting("url_error", "seriesgato"):
            raise Exception
        response = httptools.downloadpage(url_orig)
        if not response.data or "urlopen error [Errno 1]" in str(response.code):
            raise Exception
    except:
        config.set_setting("url_error", True, "seriesgato")
        try:
            response = httptools.curl_request(url_orig)
        except:
            response = ""

        if not response or not response.data:
            import random
            server_random = ['nl', 'de', 'us']
            server = server_random[random.randint(0, 2)]
            url = "https://%s.hideproxy.me/includes/process.php?action=update" % server
            post = "u=%s&proxy_formdata_server=%s&allowCookies=1&encodeURL=0&encodePage=0&stripObjects=0&stripJS=0&go=" \
                   % (url_orig, server)
            while True:
                response = httptools.downloadpage(url, post, follow_redirects=False)
                if response.headers.get("location"):
                    url = response.headers["location"]
                    post = ""
                else:
                    break

    return response.data
