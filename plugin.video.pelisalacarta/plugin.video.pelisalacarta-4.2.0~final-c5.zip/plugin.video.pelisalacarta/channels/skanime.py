# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# pelisalacarta - XBMC Plugin
# Canal para skanime
# http://blog.tvalacarta.info/plugin-xbmc/pelisalacarta/
# ------------------------------------------------------------

import re

from channels import renumbertools
from core import config
from core import httptools
from core import logger
from core import scrapertools
from core import servertools
from core.item import Item
from platformcode import platformtools


__modo_grafico__ = config.get_setting('modo_grafico', 'skanime')
__perfil__ = config.get_setting('perfil', "skanime")

# Fijar perfil de color            
perfil = [['0xFFFFE6CC', '0xFFFFCE9C', '0xFF994D00', '0xFFFE2E2E', '0xFFFFD700'],
          ['0xFFA5F6AF', '0xFF5FDA6D', '0xFF11811E', '0xFFFE2E2E', '0xFFFFD700'],
          ['0xFF58D3F7', '0xFF2E9AFE', '0xFF2E64FE', '0xFFFE2E2E', '0xFFFFD700']]
if __perfil__ < 3:
    color1, color2, color3, color4, color5 = perfil[__perfil__]
else:
    color1 = color2 = color3 = color4 = color5 = ""
host = "http://skanime.net"


def mainlist(item):
    logger.info()
    itemlist = []

    itemlist.append(Item(channel=item.channel, action="recientes", title="Episodios Recientes", thumbnail=item.thumbnail,
                         url=host, text_color=color1))
    itemlist.append(Item(channel=item.channel, action="listado", title="Novedades Animes", thumbnail=item.thumbnail,
                         url="%s/animes/" % host, text_color=color1, contentType="tvshow"))
    itemlist.append(Item(channel=item.channel, action="listado", title="Novedades Películas", thumbnail=item.thumbnail,
                         url="%s/peliculas/" % host, text_color=color1, contentType="movie"))
    itemlist.append(Item(channel=item.channel, action="indices", title="Índices Anime", thumbnail=item.thumbnail,
                         url="%s/animes/" % host, text_color=color2, contentType="tvshow"))
    itemlist.append(Item(channel=item.channel, action="indices", title="Índices Películas", thumbnail=item.thumbnail,
                         url="%s/animes/" % host, text_color=color2, contentType="movie"))


    itemlist.append(Item(channel=item.channel, action="search", title="Buscar...",
                         thumbnail=item.thumbnail, text_color=color3))

    itemlist.append(item.clone(title="Configurar canal", action="openconfig", text_color=color5, folder=False))
    if renumbertools.context:
        itemlist = renumbertools.show_option(item.channel, itemlist)
    return itemlist


def openconfig(item):
    ret = platformtools.show_channel_settings()
    platformtools.itemlist_refresh()
    return ret


def search(item, texto):
    item.url = "%s/?s=%s" % (host, texto.replace(" ", "+"))
    item.extra = "busqueda"
    try:
        return listado(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []


def recientes(item):
    logger.info()
    item.contentType = "tvshow"

    itemlist = []

    data = httptools.downloadpage(item.url).data
    patron = '<div class="not">.*?href="([^"]+)" title="([^"]+)".*?src="([^"]+)"'
    matches = scrapertools.find_multiple_matches(data, patron)
    for url, title, thumb in matches:
        thumb = thumb.replace("-300x168", "")
        try:
            contentTitle = title.split(" Cap", 1)[0]
        except:
            contentTitle = ""
        infoLabels = {'filtro': {"original_language": "ja"}.items()}
        itemlist.append(item.clone(action="findvideos", title=title, url=url, thumbnail=thumb, text_color=color3,
                                   contentTitle=contentTitle, contentSerieName=contentTitle, infoLabels=infoLabels, extra="recientes"))

    try:
        from core import tmdb
        tmdb.set_infoLabels_itemlist(itemlist, __modo_grafico__)
    except:
        pass

    return itemlist


def listado(item):
    logger.info()
    itemlist = []

    data = httptools.downloadpage(item.url).data
    patron = '<div class="fit item">.*?href="([^"]+)".*?src="([^"]+)".*?<h1>(.*?)</h1>.*?(?:rel="tag">(\d+)|<div class="a">).*?' \
             '<span>(.*?)</span>.*?<span class="dato">([^:]*).*?<div class="contenido"><p>\s*(.*?)</p>'
    matches = scrapertools.find_multiple_matches(data, patron)
    for url, thumb, title, year, status, tipo, plot in matches:
        status = scrapertools.htmlclean(status).strip()
        scrapedtitle = title
        if status:
            scrapedtitle += "  [%s]" % status
        title = re.sub(r"(?i) Ova| Especiales| Specials", "", title)
        infoLabels = {'filtro': {"original_language": "ja"}.items(), 'plot': plot}
        if year:
            infoLabels['year'] = year

        if item.extra == "busqueda":
            tipo_ = "movie"
            if "IMDB" not in tipo:
                tipo_ = "tvshow"
            item.contentType = tipo_
            
        show = ""
        action = "findvideos"
        if item.contentType == "tvshow":
            show = title
            action = "episodios"

        itemlist.append(item.clone(action=action, title=scrapedtitle, url=url, thumbnail=thumb, text_color=color3,
                                   contentTitle=title, contentSerieName=show, infoLabels=infoLabels,
                                   context=renumbertools.context))

    try:
        from core import tmdb
        tmdb.set_infoLabels_itemlist(itemlist, __modo_grafico__)
    except:
        pass

    next_page = scrapertools.find_single_match(data, "<a class='current'>.*?class='page larger' href='([^']+)'")
    if next_page and itemlist:
        itemlist.append(Item(channel=item.channel, action="listado", url=next_page, title=">> Página Siguiente",
                             thumbnail=item.thumbnail, text_color=color2, contentType=item.contentType))

    return itemlist


def indices(item):
    logger.info()
    itemlist = []
    
    if "Índices" in item.title:
        itemlist.append(item.clone(title="Por Género"))
        itemlist.append(item.clone(title="Por Año"))
    else:
        data = httptools.downloadpage(item.url).data
        if item.contentType == "movie":
            bloque = scrapertools.find_single_match(data, '<div id="moviehome".*?<div class="categorias">(.*?)<div class')
        else:
            bloque = scrapertools.find_single_match(data, '<div id="serieshome".*?<div class="categorias">(.*?)<div class')

        if "Género" in item.title:
            patron = '<li class="cat-item.*?href="([^"]+)".*?>([^<]+)<.*?<span>(\d+)</span>'
        else:
            patron = '<li><a href="([^"]+)"\s*>(\d+)'

        matches = scrapertools.find_multiple_matches(bloque, patron)
        for m in matches:
            url = m[0]
            title = m[1]
            if len(m) > 2:
                title += "  (%s)" % m[2]
            itemlist.append(item.clone(action="listado", url=url, title=title))
        
    return itemlist


def episodios(item):
    logger.info()

    itemlist = []
    data = httptools.downloadpage(item.url).data

    show = scrapertools.find_single_match(data, '<p class="lead">.*?<b>([^<]+)</b>')
    
    if not item.infoLabels.get("plot"):
        item.infoLabels["plot"] = scrapertools.find_single_match(data, 'Sinopsis:.*?<p>(.*?)</p>')

    id = scrapertools.find_single_match(data, 'window.episodioid\s*=\s*(\d+)')
    data = httptools.downloadpage("%s/episodios.php?id=%s&cambio=1-1000" % (host, id)).data
    patron = '<a href="([^"]+)".*?<img.*?>\s*(.*?)\s*</a>'
    matches = scrapertools.find_multiple_matches(data, patron)
    for url, title in matches:
        title = re.sub(r'(?i)%s' % item.contentSerieName, "", title)
        epi = scrapertools.find_single_match(title, '(?i)(?:Capítulo|Capitulo) (\d+)')
        new_item = item.clone(action="findvideos", url=url, title=title, extra="")
        if epi:
            season, episode = renumbertools.numbered_for_tratk(
                item.channel, show, 1, int(epi))
            new_item.infoLabels["episode"] = episode
            new_item.infoLabels["season"] = season

            new_item.title = "%sx%s %s" % (season, episode, title)

        itemlist.append(new_item)

    if item.infoLabels.get("tmdb_id") or item.extra == "recientes":
        try:
            from core import tmdb
            tmdb.set_infoLabels_itemlist(itemlist, __modo_grafico__)
        except:
            pass

    if config.get_library_support() and itemlist:
        itemlist.append(Item(channel=item.channel, title="Añadir serie a la biblioteca", url=item.url,
                             action="add_serie_to_library", extra="episodios", contentTitle=item.contentTitle,
                             contentSerieName=item.contentSerieName, text_color=color4, thumbnail=item.thumbnail,
                             fanart=item.fanart))

    return itemlist


def findvideos(item):
    logger.info()
    itemlist = []

    data = httptools.downloadpage(item.url).data
    post_id = scrapertools.find_single_match(data, 'window.post_id\s*=\s*(\d+)')
    patron = '<li id="([^"]+)" class="clickme">.*?>([^<]+)</a>'
    matches = scrapertools.find_multiple_matches(data, patron)
    for ref, titulo in matches:
        url = "%s/iframes.php?postid=%s&iframe=%s" % (host, post_id, ref)
        data_vid = httptools.downloadpage(url).data
        url = scrapertools.find_single_match(data_vid, '<iframe.*?src="([^"]+)"')
        if "skanime.net" in url:
            if not url.startswith("http"):
                url = "http:%s" % url
            data_vid = httptools.downloadpage(url).data
            url = scrapertools.find_single_match(data_vid, '<iframe src="([^"]+)"')
            data_vid = httptools.downloadpage(url).data
            if "vidoe.no.encontrado" not in data_vid:
                subtitle = scrapertools.find_single_match(data_vid, "tracks:\[\{file\s*:\s*'([^']+)'")
                patron = 'file\s*:\s*["\']([^"\']+)["\']\s*,\s*label\s*:\s*["\']([^"\']+)["\']'
                media_urls = scrapertools.find_multiple_matches(data_vid, patron)
                for media, label in media_urls:
                    title = "%s [directo] - %s" % (titulo, label)
                    itemlist.append(item.clone(action="play", url=media, title=title, server="directo",
                                               subtitle=subtitle))
        elif "drive.google" in url:
            title = "%s [directo] Drive" % titulo
            itemlist.append(item.clone(action="play", url=url, title=title, server="directo"))
        else:
            enlaces = servertools.findvideos(url, True)
            if enlaces:
                title = "%s [%s]" % (titulo, enlaces[0][2])
                itemlist.append(item.clone(action="play", url=enlaces[0][1], server=enlaces[0][2], title=title))

    if not itemlist:
        patron = '<div id="([^"]+)">\s*<div class="movieplay">.*?<iframe.*?src="([^"]+)"'
        matches = scrapertools.find_multiple_matches(data, patron)
        if not matches:
            patron = '<div id="([^"]+)">\s*<p><iframe.*?src="([^"]+)"'
            matches = scrapertools.find_multiple_matches(data, patron)
        for ref, url in matches:
            if not url.startswith("http"):
                url = "http:%s" % url
            repr = scrapertools.find_single_match(data, '<a href="#%s"[^>]*>\s*(.*?)\s*</a>' % ref)
            if "skanime.net" in url:
                data_vid = httptools.downloadpage(url).data
                if "vidoe.no.encontrado" not in data_vid:
                    subtitle = scrapertools.find_single_match(data_vid, "tracks:\[\{file\s*:\s*'([^']+)'")
                    patron = 'file\s*:\s*["\']([^"\']+)["\']\s*,\s*label\s*:\s*["\']([^"\']+)["\']'
                    media_urls = scrapertools.find_multiple_matches(data_vid, patron)
                    for media, label in media_urls:
                        title = "%s [directo] - %s" % (repr, label)
                        itemlist.append(item.clone(action="play", url=media, title=title, server="directo",
                                                   subtitle=subtitle))
            elif "drive.google" in url:
                title = "%s [directo] Drive" % repr
                itemlist.append(item.clone(action="play", url=url, title=title, server="directo"))
            else:
                enlaces = servertools.findvideos(url, True)
                if enlaces:
                    title = "%s [%s]" % (repr, enlaces[0][2])
                    itemlist.append(item.clone(action="play", url=enlaces[0][1], server=enlaces[0][2], title=title))

    patron = '<li class="elemento">.*?href="([^"]+)".*?<span class="b">\s*(.*?)</span>.*?<span class="c">(.*?)</span>' \
             '.*?<span class="d">(.*?)</span>'
    matches = scrapertools.find_multiple_matches(data, patron)
    for url, servidor, idioma, calidad in matches:
        servidor = scrapertools.htmlclean(servidor).strip()
        title = "%s [%s/%s]" % (servidor, idioma, calidad)
        if "skanime.net" in url:
            data_vid = httptools.downloadpage(url).data
            hash = scrapertools.find_single_match(data_vid, 'var hash\s*=\s*"([^"]+)"')
            if hash:
                import base64
                import urllib
                url = urllib.unquote(base64.b64decode(hash))
                if "cldup.com" in url or "animemovil" in url or "skanime" in url:
                    url = url.replace("&amp;", "&")
                    itemlist.append(item.clone(action="play", url=url, title=title, server="directo"))
                else:
                    enlaces = servertools.findvideos(url, True)
                    if enlaces:
                        server = enlaces[0][2]
                        if server == "mega":
                            try:
                                from megaserver import Client
                                c = Client(url=url, is_playing_fnc=platformtools.is_playing)
                                files = c.get_files()
                                video_urls = []
                                for f in files:
                                    title = "Mega - %s" % f["name"]
                                    itemlist.append(item.clone(action="play", url=f["url"], title=title, server="directo"))
                            except:
                                pass
                        else:
                            url = enlaces[0][1]
                            title += "  (%s)" % server
                            itemlist.append(item.clone(action="play", url=url, title=title, server=server))
        else:
            enlaces = servertools.findvideos(url, True)
            if enlaces:
                url = enlaces[0][1]
                server = enlaces[0][2]
                title += "  (%s)" % server
                itemlist.append(item.clone(action="play", url=url, title=title, server=server))
                
    if not itemlist:
        itemlist.append(Item(channel=item.channel, title="No hay vídeos disponibles", action=""))
    if item.extra == "recientes":
        url = scrapertools.find_single_match(data, '<a href="([^"]+)" class="icon-list">')
        if url:
            itemlist.append(item.clone(action="episodios", title="Ir a lista de capítulos", url=url, text_color=color1))
    elif item.contentType == "movie" and config.get_library_support():
        if "No hay vídeos disponibles" not in itemlist[0].title:
            itemlist.append(Item(channel=item.channel, title="Añadir película a la biblioteca", url=item.url,
                                 action="add_pelicula_to_library", contentTitle=item.contentTitle, text_color=color4,
                                 thumbnail=item.thumbnail, fanart=item.fanart))
        

    return itemlist


def play(item):
    logger.info()
    if "skanime.net" in item.url:
        response = httptools.downloadpage(item.url, follow_redirects=False)
        url = response.headers.get("location", "")
        if not url:
            url = scrapertools.find_single_match(response.data, 'document.write\(["\']([^"\']+)["\']')
        if url:
            item.url = url
    elif "drive.google" in item.url:
        itemlist = []
        import urllib
        docid = scrapertools.find_single_match(item.url, '/d/([^/]+)/')
        url = "http://docs.google.com/get_video_info?docid=%s" % docid

        headers = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20150101 Firefox/47.0 (Chrome)',
            'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'en-us,en;q=0.5',
        }
        response = httptools.downloadpage(url, cookies=False)
        cookies = ""
        cookie = response.headers["set-cookie"].split("HttpOnly, ")
        for c in cookie:
            cookies += c.split(";", 1)[0]+"; "

        data = response.data.decode('unicode-escape')
        data = urllib.unquote_plus(urllib.unquote_plus(data))

        headers_string = "|"
        for key, value in headers.items():
            headers_string += key + "=" + value + "&"
        headers_string += "Cookie="+cookies
        url_streams = scrapertools.find_single_match(data, 'url_encoded_fmt_stream_map=(.*)')
        streams = scrapertools.find_multiple_matches(url_streams, 'url=(.*?)(?:;.*?quality=(.*?)(?:,|&)|&quality=(.*?)(?:,|&))')
        for video_url, quality, quality2 in streams:
            ext = scrapertools.find_single_match(video_url, '&type=video/(?:x-|)(.*)').encode('utf-8')
            if ext == "mp4":
                ext = ".mp4"
            video_url += headers_string
            quality = quality.encode('utf-8')
            if not quality:
                quality = quality2.encode('utf-8')
            itemlist.append(['%s %s [directo]' % (ext, quality), video_url])
        itemlist.sort(key=lambda it:it[0], reverse=True)
        return itemlist

    return [item]


def newest(categoria):
    logger.info()
    item = Item()
    try:
        item.url = "http://skanime.net/"
        itemlist = recientes(item)
    # Se captura la excepción, para no interrumpir al canal novedades si un canal falla
    except:
        import sys
        for line in sys.exc_info():
            logger.error("{0}".format(line))
        return []

    return itemlist
