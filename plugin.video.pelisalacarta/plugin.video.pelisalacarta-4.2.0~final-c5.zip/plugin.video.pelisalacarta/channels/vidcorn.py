# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# pelisalacarta - XBMC Plugin
# Canal para vidcorn
# http://blog.tvalacarta.info/plugin-xbmc/pelisalacarta/
# ------------------------------------------------------------

import re

from core import config
from core import httptools
from core import logger
from core import scrapertools
from core.item import Item

__modo_grafico__ = config.get_setting("modo_grafico", "vidcorn")
__perfil__ = config.get_setting("perfil", "vidcorn")

# Fijar perfil de color            
perfil = [['0xFFFFE6CC', '0xFFFFCE9C', '0xFF994D00', '0xFFFE2E2E', '0xFFFFD700'],
          ['0xFFA5F6AF', '0xFF5FDA6D', '0xFF11811E', '0xFFFE2E2E', '0xFFFFD700'],
          ['0xFF58D3F7', '0xFF2E9AFE', '0xFF2E64FE', '0xFFFE2E2E', '0xFFFFD700']]
if __perfil__ < 3:
    color1, color2, color3, color4, color5 = perfil[__perfil__]
else:
    color1 = color2 = color3 = color4 = color5 = ""

host = "https://vidcorn.com"
token = ""


def mainlist(item):
    logger.info()
    itemlist = []
    item.text_color = color1

    config.set_setting("url_error", False, "vidcorn")
    config.set_setting("cookie", "", "vidcorn")
    data = get_data(host, "")
    if data == "Error":
        itemlist.append(item.clone(title="Este canal no es compatible con esta versión o programa", action=""))
        config.set_setting("include_in_global_search", False, "vidcorn")
        return itemlist

    itemlist.append(item.clone(title="Películas", action="", text_color=color2))
    item.contentType = "movie"
    itemlist.append(item.clone(title="     Novedades", action="fichas", post="data_type=peliculas&filter_by=all&order_by=2", page=0))
    itemlist.append(item.clone(title="     Populares", action="fichas", post="data_type=peliculas&filter_by=all&order_by=1", page=0))
    itemlist.append(item.clone(title="     Géneros", action="indices"))

    itemlist.append(item.clone(title="Series", action="", text_color=color2))
    item.contentType = "tvshow"
    itemlist.append(item.clone(title="     Novedades", action="fichas", post="data_type=series&filter_by=all&order_by=2", page=0))
    itemlist.append(item.clone(title="     Populares", action="fichas", post="data_type=series&filter_by=all&order_by=1", page=0))
    itemlist.append(item.clone(title="     Géneros", action="indices"))

    item.contentType = ""
    itemlist.append(item.clone(title="Listas", action="listas", text_color=color2, post="order_by=1", page=0))
    itemlist.append(item.clone(action="search", title="Buscar...", text_color=color2))

    itemlist.append(item.clone(title="Configuración del canal", action="configuracion", text_color="gold"))

    return itemlist


def configuracion(item):
    from platformcode import platformtools
    ret = platformtools.show_channel_settings()
    platformtools.itemlist_refresh()
    return ret


def search(item, texto):
    logger.info()
    try:
        item.url = "%s/buscar/%s"  % (host, texto.replace(" ", "-"))
        item.page = 0
        item.action = "buscar"
        return buscar(item)
    # Se captura la excepción, para no interrumpir al buscador global si un canal falla
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []


def buscar(item):
    logger.info()
    itemlist = []
    item.text_color = color2

    data = get_data(item.url, "")

    patron = '<div\s*itemscope.*?data-item="([^"]+)".*?data-type="([^"]+)" data-item="([^"]+)"' \
             '.*?<a(.*?)</a>.*?<span class="year">\s*(\d+).*?<h3>(.*?)<'
    matches = scrapertools.find_multiple_matches(data, patron)
    for tmdb_id, tipo, id_vid, thumb, year, title in matches[item.page:item.page + 25]:
        url = "movie=%s&filters=all-all-all-all-add_date&data_type=%s" % (id_vid, tipo)
        thumb = scrapertools.find_single_match(thumb, 'data-original="([^"]+)"')

        new_item = item.clone(url=url, thumbnail=thumb, contentTitle=title, title=title,
                              context="buscar_trailer", post="")

        new_item.action = "findvideos"
        new_item.contentType = "movie"
        if tipo == "series":
            new_item.contentSerieName = title
            new_item.action = "episodios"
            new_item.contentType = "tvshow"

        new_item.infoLabels['tmdb_id'] = tmdb_id
        new_item.infoLabels['year'] = year
        itemlist.append(new_item)

    try:
        from core import tmdb
        tmdb.set_infoLabels_itemlist(itemlist, __modo_grafico__)
    except:
        pass

    if len(matches) > item.page + 25:
        itemlist.append(item.clone(title=">> Página Siguiente", page=25, text_color=color3))

    return itemlist


def fichas(item):
    logger.info()
    itemlist = []
    item.text_color = color2

    if "list=" in item.post:
        post = "page=%s&%s" % (item.page, item.post)
        data = get_data("%s/assets/ajax/fetch_list_content" % host, post)
    else:
        post = "page=%s&%s&keyword=0&optradio=0" % (item.page, item.post)
        data = get_data("%s/assets/ajax/fetch_pages" % host, post)

    patron = '<div\s*itemscope.*?data-item="([^"]+)".*?data-type="([^"]+)" data-item="([^"]+)"' \
             '.*?<a(.*?)</a>.*?<span class="year">\s*(\d+).*?<h3>(.*?)<'
    matches = scrapertools.find_multiple_matches(data, patron)
    for tmdb_id, tipo, id_vid, thumb, year, title in matches:
        url = "movie=%s&filters=all-all-all-all-add_date&data_type=%s" % (id_vid, tipo)
        thumb = scrapertools.find_single_match(thumb, 'data-original="([^"]+)"')

        new_item = item.clone(url=url, thumbnail=thumb, contentTitle=title, title=title,
                              context="buscar_trailer", post="", id=id_vid)

        new_item.action = "findvideos"
        new_item.contentType = "movie"
        if tipo == "series":
            new_item.contentSerieName = title
            new_item.action = "episodios"
            new_item.contentType = "tvshow"

        new_item.infoLabels['tmdb_id'] = tmdb_id
        new_item.infoLabels['year'] = year
        itemlist.append(new_item)

    try:
        from core import tmdb
        tmdb.set_infoLabels_itemlist(itemlist, __modo_grafico__)
    except:
        pass

    if "load_more_button').show()" in data:
        itemlist.append(item.clone(page=item.page+1, title=">> Página Siguiente", text_color=color3))
        
    return itemlist



def indices(item):
    logger.info()
    itemlist = []

    if item.contentType == "movie":
        data = get_data("%s/peliculas" % host, "")
    else:
        data = get_data("%s/series" % host, "")

    bloque = scrapertools.find_single_match(data, '<ul id="genero-filter-selector"(.*?)</ul>')
    patron = '<li data-value="([^"]+)"><a>(.*?)</a></li>'
    matches = scrapertools.find_multiple_matches(bloque, patron)
    for id, title in matches:
        url = "data_type=peliculas&filter_by=%s&order_by=1" % id
        if item.contentType == "tvshow":
            url = "data_type=series&filter_by=%s&order_by=1" % id
        itemlist.append(item.clone(title=title, action="fichas", post=url, page=0, text_color=color2))
        
    return itemlist


def episodios(item):
    logger.info()
    itemlist = []

    data = get_data("%s/assets/ajax/fetch_links" % host, item.url)

    patron = '<a class="temporada" data-season="([^"]+)".*?title="([^"]+)"(.*?)</a>\s*</div>\s*</div>'
    bloques = scrapertools.find_multiple_matches(data, patron)
    for season, vista, episodes in bloques:
        patron = 'data-episodio="([^"]+)".*?<span class=\'num_ep\'>(.*?)</span>.*?' \
                 '<span class=\'nom_ep\'>(.*?)</span>.*?<small class="fecha-episodio">(.*?)<' \
                 '.*?title="([^"]+)"'
        matches = scrapertools.find_multiple_matches(episodes, patron)
        for data_epi, epi, title, fecha, visto in matches:
            new_item = item.clone(action="findvideos", contentType="episode", url="episode=%s" % data_epi)
            new_item.title = "%sx%s  %s" % (season, epi, title.strip())
            if fecha:
                new_item.title += "  (%s)" % fecha
            
            new_item.infoLabels['season'] = season
            new_item.infoLabels['episode'] = epi
            itemlist.append(new_item)

    itemlist.sort(key=lambda it: (it.infoLabels.get('season', 0), it.infoLabels.get('episode', 0)), reverse=True)

    try:
        from core import tmdb
        tmdb.set_infoLabels_itemlist(itemlist, __modo_grafico__)
    except:
        pass

    if config.get_library_support() and not item.extra:
        itemlist.append(Item(channel=item.channel, title="Añadir esta serie a la biblioteca", url=item.url,
                             action="add_serie_to_library", extra="episodios", contentSerieName=item.contentSerieName,
                             text_color="green", thumbnail=item.thumbnail, infoLabels=item.infoLabels,
                             fanart=item.fanart))

    return itemlist


def listas(item):
    logger.info()

    itemlist = []
    item.text_color = color2
    import random

    post = "page=%s&%s&keyword=0" % (item.page, item.post)
    data = get_data("%s/assets/ajax/fetch_lists" % host, post)
    patron = '<div data-list="([^"]+)".*?<strong class="list-name">(.*?)</strong>(.*?)</a>\s*</div>\s*</div>'
    bloques = scrapertools.find_multiple_matches(data, patron)
    for id_list, titulo, b in bloques:
        images = scrapertools.find_multiple_matches(b, 'data-original="([^"]+)"')
        thumb = images[random.randint(0, len(images)-1)]
        thumb = thumb.replace("/tiny/", "/default/")
        url = "list=%s" % id_list
        itemlist.append(item.clone(title=titulo, thumbnail=thumb, action="fichas", post=url, page=0))

    if "load_more_button').show()" in data:
        itemlist.append(item.clone(page=item.page+1, title=">> Página Siguiente"))

    return itemlist


def findvideos(item):
    logger.info()

    itemlist = []
    item.text_color = color3

    suffix = ""
    if item.contentType != "movie":
        suffix = "_from_episode"
    
    data = get_data("%s/assets/ajax/fetch_links%s" % (host, suffix), item.url)

    patron = 'href="([^"]+)"><li data-link.*?<img.*?>(.*?)\s*<.*?Idioma:\s*([^"]+)".*?Subtitulos:\s*([^"]+)"' \
             '.*?Calidad:\s*([^"]+)".*?<span class="thumbs-up">(\d+).*?<span class="thumbs-down">(\d+)'
    matches = scrapertools.find_multiple_matches(data, patron)
    for url, server, idioma, sub, calidad, up, down in matches:
        url = host + url
        if "." in server:
            server = server.rsplit(".", 1)[0]
        server = server.replace("streamin", "streaminto").replace("thevideo", "thevideome") \
                       .replace("uploaded", "uploadedto").replace("vidto", "vidtome") \
            
        if "Latino" in idioma:
            idioma = "Latino"
        elif "España" in idioma:
            idioma = "Castellano"
        title = "%s  -  %s/%s" % (server.capitalize(), idioma, calidad)
        if "Sin" not in sub and idioma != "Inglés":
            title += " [%s]" % sub

        title += " ([COLOR green]+%s[/COLOR]|[COLOR red]-%s[/COLOR])" % (up, down)
        itemlist.append(item.clone(action="play", url=url, title=title, server=server))

    if not itemlist:
        itemlist.append(item.clone(action="", title="No hay enlaces disponibles"))
    elif item.contentType == "movie" and config.get_library_support():
        itemlist.append(Item(channel=item.channel, title="Añadir esta película a la biblioteca", url=item.url,
                             action="add_pelicula_to_library", text_color="green", thumbnail=item.thumbnail,
                             infoLabels=item.infoLabels, fanart=item.fanart))

    return itemlist


def play(item):
    logger.info()
    itemlist = []

    data = get_data(item.url, "")
    data_v = scrapertools.find_single_match(data, 'data-v="([^"]+)"')
    data = get_data("%s/v" % host, "vr_async=%s" % data_v)
    url = get_data("%s/r/%s" % (host, data), "", True, item.url)

    from core import servertools
    enlaces = servertools.findvideosbyserver(url, item.server)
    if not enlaces:
        enlaces = servertools.findvideos(url, True)
    if enlaces:
        itemlist.append(item.clone(url=enlaces[0][1], server=enlaces[0][2]))

    return itemlist


def get_data(url_orig, post, location=False, referer=host):
    try:
        if config.get_setting("url_error", "vidcorn"):
            raise Exception
        headers = {'Referer': referer}
        if post:
            headers['X-Requested-With'] = 'XMLHttpRequest'
        if location:
            response = httptools.downloadpage(url_orig, post, headers, follow_redirects=False).headers["location"]
            if response:
                return response
        else:
            response = httptools.downloadpage(url_orig, post, headers)
        if not response or not response.data or "urlopen error [Errno 1]" in str(response.code):
            raise Exception
    except:
        config.set_setting("url_error", True, "vidcorn")
        headers = {'Referer': referer}
        if post:
            headers['X-Requested-With'] = 'XMLHttpRequest'
        try:
            if location:
                response = httptools.curl_request(url_orig, post, headers, follow_redirects=False, only_headers=True).headers["location"]
                if response:
                    return response
            else:
                response = httptools.curl_request(url_orig, post, headers)
            if not response or not response.data or "urlopen error [Errno 1]" in str(response.code):
                raise Exception
        except:
            return "Error"

    return response.data
